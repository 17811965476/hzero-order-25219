## HZero 0.9.0.RELEASE

### 历史版本

* [0.8.0.RELEASE](https://code.choerodon.com.cn/hzero-hzero/hzero-resource/tree/0.8.0.RELEASE)
* [0.9.0.RELEASE](https://code.choerodon.com.cn/hzero-hzero/hzero-resource/tree/0.9.0.RELEASE)

### 说明

这个项目中提供了`0.10.0.RELEASE`的初始化内容，包括数据库脚本以及初始数据。
HZero使用**猪齿鱼**提供的Liquibase工具管理数据库脚本以及初始数据，最新的工具版本为`0.10.0`，[点击下载工具。](https://nexus.choerodon.com.cn/repository/choerodon-release/io/choerodon/choerodon-tool-liquibase/0.10.0.RELEASE/choerodon-tool-liquibase-0.10.0.RELEASE.jar)

### 初始化工具指南

* 使用下方脚本执行数据库初始化和数据初始化，需要替换以下配置
    - `spring.datasource.url`：数据库连接URL
    - `spring.datasource.username`：数据库名称
    - `spring.datasource.password`：数据库密码
    - `data.dir`:初始化内容文件夹目录
    - `data.update.exclusion`:排除数据更新的表或列

```sh
#!/usr/bin/env bash
mkdir -p tool-jar
if [ ! -f tool-jar/choerodon-tool-liquibase.jar ]
then
    curl https://nexus.choerodon.com.cn/repository/choerodon-release/io/choerodon/choerodon-tool-liquibase/0.10.0.RELEASE/choerodon-tool-liquibase-0.10.0.RELEASE.jar -o ./tool-jar/choerodon-tool-liquibase.jar
fi

java -Dspring.datasource.url="Please edit..." \
     -Dspring.datasource.username=Please edit... \
     -Dspring.datasource.password=Please edit... \
     -Ddata.drop=false -Ddata.init=init \
     -Ddata.update.exclusion=table1,table2,table3.column \
     -Ddata.dir=Please edit... \
     -jar tool-jar/choerodon-tool-liquibase.jar
```

* 如果执行脚本无法正确下载Jar，可以自行下载，然后改名为`choerodon-tool-liquibase.jar`存放在`tool-jar`或者自己指定的文件夹中。