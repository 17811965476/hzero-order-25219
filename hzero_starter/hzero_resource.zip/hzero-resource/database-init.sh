#!/usr/bin/env bash
mkdir -p tool-jar
if [ ! -f tool-jar/choerodon-tool-liquibase.jar ]
then
    curl https://nexus.choerodon.com.cn/repository/choerodon-release/io/choerodon/choerodon-tool-liquibase/0.10.0.RELEASE/choerodon-tool-liquibase-0.10.0.RELEASE.jar -o ./tool-jar/choerodon-tool-liquibase.jar
fi

service=hzero_governance
schema=$service
dir=init-data/$service


java -Dspring.datasource.url="jdbc:mysql://db.hzero.org:3306/$schema?useUnicode=true&characterEncoding=utf-8&useSSL=false" \
     -Dspring.datasource.username=hzero \
     -Dspring.datasource.password=hzero \
     -Ddata.drop=false \
	 -Ddata.init=true \
     -Ddata.dir=$dir \
	 -Ddata.update.exclusion= \
	 -Dlogging.level.root=info \
     -jar tool-jar/choerodon-tool-liquibase.jar



	 