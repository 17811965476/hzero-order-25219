package script.db

databaseChangeLog(logicalFilePath: 'script/db/hpfm_ui_table_conf_line.groovy') {
    changeSet(author: "xingxing.wu@hand-china.com", id: "2019-04-16-hpfm_ui_table_conf_line") {
        def weight = 1
        if(helper.isSqlServer()){
            weight = 2
        } else if(helper.isOracle()){
            weight = 3
        }
        if(helper.dbType().isSupportSequence()){
            createSequence(sequenceName: 'hpfm_ui_table_conf_line_s', startValue:"1")
        }
        createTable(tableName: "hpfm_ui_table_conf_line", remarks: "UI表格配置行") {
            column(name: "table_conf_line_id", type: "bigint(20)", autoIncrement: true ,   remarks: "表ID，主键，供其他表做外键")  {constraints(primaryKey: true)} 
            column(name: "table_conf_id", type: "bigint(20)",  remarks: "表格配置行ID")  {constraints(nullable:"false")}  
            column(name: "data_index", type: "varchar(" + 80 * weight + ")",  remarks: "表格列索引")  {constraints(nullable:"false")}  
            column(name: "fixed_type", type: "varchar(" + 30 * weight + ")",   defaultValue:"NONE",   remarks: "固定类型，HPFM.UI_TABLE_FIXED_TYPE，NONE/LEFT/RIGHT/BOTH")  {constraints(nullable:"false")}  
            column(name: "width", type: "int(11)",  remarks: "宽度")  {constraints(nullable:"false")}  
            column(name: "display", type: "tinyint(1)",   defaultValue:"1",   remarks: "是否显示")  {constraints(nullable:"false")}  
            column(name: "order_seq", type: "int(11)",  remarks: "排序号")   
            column(name: "remark", type: "longtext",  remarks: "备注说明")   
            column(name: "object_version_number", type: "bigint(20)",   defaultValue:"1",   remarks: "行版本号，用来处理锁")  {constraints(nullable:"false")}  
            column(name: "creation_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "created_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_updated_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_update_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  

        }

        addUniqueConstraint(columnNames:"table_conf_id,data_index",tableName:"hpfm_ui_table_conf_line",constraintName: "hpfm_ui_table_conf_line_u1")
    }
}