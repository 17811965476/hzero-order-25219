package script.db

databaseChangeLog(logicalFilePath: 'script/db/hpfm_personality_detail.groovy') {
    changeSet(author: "shuangfei.zhu@hand-china.com", id: "2019-06-03-hpfm_personality_detail") {
        def weight = 1
        if(helper.isSqlServer()){
            weight = 2
        } else if(helper.isOracle()){
            weight = 3
        }
        if(helper.dbType().isSupportSequence()){
            createSequence(sequenceName: 'hpfm_personality_detail_s', startValue:"1")
        }
        createTable(tableName: "hpfm_personality_detail", remarks: "个性化明细") {
            column(name: "personality_detail_id", type: "bigint(20)", autoIncrement: true ,   remarks: "表ID，主键，供其他表做外键")  {constraints(primaryKey: true)} 
            column(name: "personality_id", type: "bigint(20)",  remarks: "个性化hpfm_personality.personality_id")  {constraints(nullable:"false")}  
            column(name: "field_name", type: "varchar(" + 30 * weight + ")",  remarks: "字段名")  {constraints(nullable:"false")}  
            column(name: "field_description", type: "varchar(" + 30 * weight + ")",  remarks: "字段描述")   
            column(name: "field_props", type: "longtext",  remarks: "字段属性")  {constraints(nullable:"false")}  
            column(name: "field_type", type: "varchar(" + 30 * weight + ")",  remarks: "字段类型")  {constraints(nullable:"false")}  
            column(name: "field_enabled_flag", type: "tinyint(1)",  remarks: "启用标识")  {constraints(nullable:"false")}  
            column(name: "object_version_number", type: "bigint(20)",   defaultValue:"1",   remarks: "行版本号，用来处理锁")  {constraints(nullable:"false")}  
            column(name: "creation_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "created_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_updated_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_update_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  

        }

        addUniqueConstraint(columnNames:"personality_id,field_name",tableName:"hpfm_personality_detail",constraintName: "hpfm_personality_detail_u1")
    }
}