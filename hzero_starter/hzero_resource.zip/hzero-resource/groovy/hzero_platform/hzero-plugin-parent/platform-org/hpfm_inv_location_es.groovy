package script.db

databaseChangeLog(logicalFilePath: 'script/db/hpfm_inv_location_es.groovy') {
    changeSet(author: "hzero@hand-china.com", id: "2019-03-01-hpfm_inv_location_es") {
        def weight = 1
        if(helper.isSqlServer()){
            weight = 2
        } else if(helper.isOracle()){
            weight = 3
        }
        if(helper.dbType().isSupportSequence()){
            createSequence(sequenceName: 'hpfm_inv_location_es_s', startValue:"1")
        }
        createTable(tableName: "hpfm_inv_location_es", remarks: "货位关联表") {
            column(name: "location_es_id", type: "bigint(20)", autoIncrement: true ,   remarks: "表ID，主键，供其他表做外键")  {constraints(primaryKey: true)} 
            column(name: "external_system_code", type: "varchar(" + 30 * weight + ")",  remarks: "外部系统代码")  {constraints(nullable:"false")}  
            column(name: "location_id", type: "bigint(20)",  remarks: "hzero平台货位id")  {constraints(nullable:"false")}  
            column(name: "es_inventory_id", type: "varchar(" + 50 * weight + ")",  remarks: "erp库存id")   
            column(name: "es_inventory_code", type: "varchar(" + 30 * weight + ")",  remarks: "erp库存代码")   
            column(name: "es_organization_id", type: "varchar(" + 50 * weight + ")",  remarks: "erp库存组织id")   
            column(name: "es_organization_code", type: "varchar(" + 30 * weight + ")",  remarks: "erp库存组织代码")   
            column(name: "es_ou_id", type: "varchar(" + 50 * weight + ")",  remarks: "erp业务实体id")   
            column(name: "es_ou_code", type: "varchar(" + 30 * weight + ")",  remarks: "erp业务实体代码")   
            column(name: "es_location_id", type: "varchar(" + 50 * weight + ")",  remarks: "erp货位id")   
            column(name: "es_location_code", type: "varchar(" + 30 * weight + ")",  remarks: "erp货位代码")   
            column(name: "data_version", type: "bigint(20)",  remarks: "erp数据版本号")  {constraints(nullable:"false")}  
            column(name: "object_version_number", type: "bigint(20)",   defaultValue:"1",   remarks: "行版本号，用来处理锁")  {constraints(nullable:"false")}  
            column(name: "creation_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "created_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_updated_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_update_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  

        }

        addUniqueConstraint(columnNames:"external_system_code,location_id",tableName:"hpfm_inv_location_es",constraintName: "hpfm_inv_location_es_u1")
        addUniqueConstraint(columnNames:"external_system_code,es_inventory_id,es_inventory_code,es_organization_id,es_organization_code,es_ou_id,es_ou_code,es_location_id,es_location_code",tableName:"hpfm_inv_location_es",constraintName: "hpfm_inv_location_es_u2")
    }
}