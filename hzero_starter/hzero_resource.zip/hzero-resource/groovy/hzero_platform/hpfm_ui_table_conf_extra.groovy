package script.db

databaseChangeLog(logicalFilePath: 'script/db/hpfm_ui_table_conf_extra.groovy') {
    changeSet(author: "xingxing.wu@hand-china.com", id: "2019-04-16-hpfm_ui_table_conf_extra") {
        def weight = 1
        if(helper.isSqlServer()){
            weight = 2
        } else if(helper.isOracle()){
            weight = 3
        }
        if(helper.dbType().isSupportSequence()){
            createSequence(sequenceName: 'hpfm_ui_table_conf_extra_s', startValue:"1")
        }
        createTable(tableName: "hpfm_ui_table_conf_extra", remarks: "UI表格配置额外属性") {
            column(name: "table_conf_extra_id", type: "bigint(20)", autoIncrement: true ,   remarks: "表ID，主键，供其他表做外键")  {constraints(primaryKey: true)} 
            column(name: "table_conf_line_id", type: "bigint(20)",  remarks: "表格配置行ID")   
            column(name: "table_conf_id", type: "bigint(20)",  remarks: "表格配置头ID")  {constraints(nullable:"false")}  
            column(name: "property_owner", type: "varchar(" + 30 * weight + ")",  remarks: "属性属主，HPFM.UI_TABLE_PROPERTY_OWNER，TABLE/COLUMN-COLUMN时table_conf_line_id必输")  {constraints(nullable:"false")}  
            column(name: "property_name", type: "varchar(" + 60 * weight + ")",  remarks: "属性名")  {constraints(nullable:"false")}  
            column(name: "property_value", type: "varchar(" + 255 * weight + ")",  remarks: "属性值")  {constraints(nullable:"false")}  
            column(name: "remark", type: "longtext",  remarks: "备注说明")   
            column(name: "object_version_number", type: "bigint(20)",   defaultValue:"1",   remarks: "行版本号，用来处理锁")  {constraints(nullable:"false")}  
            column(name: "creation_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "created_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_updated_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_update_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  

        }

        addUniqueConstraint(columnNames:"table_conf_id,table_conf_line_id,property_owner,property_name",tableName:"hpfm_ui_table_conf_extra",constraintName: "hpfm_ui_table_conf_extra_u1")
    }
}