package script.db

databaseChangeLog(logicalFilePath: 'script/db/hpfm_personality.groovy') {
    changeSet(author: "shuangfei.zhu@hand-china.com", id: "2019-06-03-hpfm_personality") {
        def weight = 1
        if(helper.isSqlServer()){
            weight = 2
        } else if(helper.isOracle()){
            weight = 3
        }
        if(helper.dbType().isSupportSequence()){
            createSequence(sequenceName: 'hpfm_personality_s', startValue:"1")
        }
        createTable(tableName: "hpfm_personality", remarks: "个性化") {
            column(name: "personality_id", type: "bigint(20)", autoIncrement: true ,   remarks: "表ID，主键，供其他表做外键")  {constraints(primaryKey: true)} 
            column(name: "personality_code", type: "varchar(" + 30 * weight + ")",  remarks: "个性化编码")  {constraints(nullable:"false")}  
            column(name: "description", type: "varchar(" + 120 * weight + ")",  remarks: "个性化描述")   
            column(name: "enabled_flag", type: "tinyint(1)",  remarks: "启用标识")  {constraints(nullable:"false")}  
            column(name: "scope", type: "varchar(" + 30 * weight + ")",  remarks: "层级")  {constraints(nullable:"false")}  
            column(name: "user_id", type: "bigint(20)",  remarks: "用户ID,iam_user.id")   
            column(name: "role_id", type: "bigint(20)",  remarks: "角色ID,iam_role.id")   
            column(name: "tenant_id", type: "bigint(20)",  remarks: "租户ID,hpfm_tenant.tenant_id")   
            column(name: "object_version_number", type: "bigint(20)",   defaultValue:"1",   remarks: "行版本号，用来处理锁")  {constraints(nullable:"false")}  
            column(name: "creation_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "created_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_updated_by", type: "bigint(20)",   defaultValue:"-1",   remarks: "")  {constraints(nullable:"false")}  
            column(name: "last_update_date", type: "datetime",   defaultValueComputed:"CURRENT_TIMESTAMP",   remarks: "")  {constraints(nullable:"false")}  

        }
   createIndex(tableName: "hpfm_personality", indexName: "hpfm_personality_n1") {
            column(name: "personality_code")
            column(name: "scope")
        }

    }
}