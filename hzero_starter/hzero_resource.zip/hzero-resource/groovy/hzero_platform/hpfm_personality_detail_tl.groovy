package script.db

databaseChangeLog(logicalFilePath: 'script/db/hpfm_personality_detail_tl.groovy') {
    changeSet(author: "shuangfei.zhu@hand-china.com", id: "2019-06-03-hpfm_personality_detail_tl") {
        def weight = 1
        if(helper.isSqlServer()){
            weight = 2
        } else if(helper.isOracle()){
            weight = 3
        }
        if(helper.dbType().isSupportSequence()){
            createSequence(sequenceName: 'hpfm_personality_detail_tl_s', startValue:"1")
        }
        createTable(tableName: "hpfm_personality_detail_tl", remarks: "个性化明细多语言") {
            column(name: "personality_detail_id", type: "bigint(20)",  remarks: "个性化明细ID")  {constraints(nullable:"false")}  
            column(name: "lang", type: "varchar(" + 30 * weight + ")",  remarks: "语言")  {constraints(nullable:"false")}  
            column(name: "field_description", type: "varchar(" + 120 * weight + ")",  remarks: "字段描述")   

        }

        addUniqueConstraint(columnNames:"personality_detail_id,lang",tableName:"hpfm_personality_detail_tl",constraintName: "hpfm_personality_detail_tl_u1")
    }
}